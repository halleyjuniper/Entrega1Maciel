from django.urls import path, include
from bbdd import views

urlpatterns = [
    path('', views.inicio,name="Inicio"),
    path('buscar/', views.buscar),
    path('personas/', views.base,name="Personas"),
    path('personasAPI/', views.baseAPI),
    path('buscarPersona/', views.buscarPersona),
    path('mapas/', views.mapas,name="Mapas"),
    path('mapasAPI/', views.mapasAPI),
    path('inusuales/', views.inusuales,name="Inusuales"),
    path('inusualesAPI', views.inusualesAPI),
]