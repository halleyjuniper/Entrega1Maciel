from django.shortcuts import render
from django.http import HttpResponse
from bbdd.models import Persona, Mapa, Inusual
from bbdd.forms import PersonaFormulario, MapaFormulario, InusualFormulario
from django.core import serializers

# Create your views here.

def inicio(request):
    return render(request, "bbdd/inicio.html")

def buscar(request):
    return HttpResponse(f'buscando persona {request.GET["dni"]}')

def base(request):
    if request.method == "POST":

        miFormulario = PersonaFormulario(request.POST)
        print(miFormulario)

        if miFormulario.is_valid:
            informacion = miFormulario.cleaned_data
            persona = Persona(nombre=informacion["nombre"], dni=informacion["dni"], fn=informacion["fn"])
            persona.save()
            return render(request, "bbdd/inicio.html")
    else:
        miFormulario = PersonaFormulario()

    return render(request, "bbdd/personas.html", {"miFormulario": miFormulario})

def baseAPI(request):
    todos = Persona.objects.all()
    return HttpResponse(serializers.serialize('json',todos))

def buscarPersona(request):
    return render(request, "bbdd/busquedaPersona.html")

def mapas(request):
    if request.method == "POST":

        miFormulario = MapaFormulario(request.POST)
        print(miFormulario)

        if miFormulario.is_valid:
            informacion = miFormulario.cleaned_data
            mapa = Mapa(mapa=informacion["mapa"], dni=informacion["dni"], tier=informacion["tier"])
            mapa.save()
            return render(request, "bbdd/inicio.html")
    else:
        miFormulario = MapaFormulario()

    return render(request, "bbdd/mapas.html", {"miFormulario": miFormulario})

def mapasAPI(request):
    todos = Mapa.objects.all()
    return HttpResponse(serializers.serialize('json', todos))

def inusuales(request):
    if request.method == "POST":

        miFormulario = InusualFormulario(request.POST)
        print(miFormulario)

        if miFormulario.is_valid:
            informacion = miFormulario.cleaned_data
            inusual = Inusual(cosmetico=informacion["cosmetico"], clase=informacion["clase"], efecto=informacion["efecto"], item=informacion["item"])
            inusual.save()
            return render(request, "bbdd/inicio.html")
    else:
        miFormulario = InusualFormulario()

    return render(request, "bbdd/inusuales.html", {"miFormulario": miFormulario})

def inusualesAPI(request):
    todos = Inusual.objects.all()
    return HttpResponse(serializers.serialize('json', todos))

