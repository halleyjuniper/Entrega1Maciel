from django.contrib import admin
from bbdd.models import Persona

admin.site.register(Persona)