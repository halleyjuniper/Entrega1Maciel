from django import forms

class PersonaFormulario(forms.Form):
    nombre = forms.CharField()
    dni = forms.IntegerField()
    fn = forms.DateField()

class MapaFormulario(forms.Form):
    mapa = forms.CharField()
    dni = forms.IntegerField()
    tier = forms.IntegerField()

class InusualFormulario(forms.Form):
    cosmetico = forms.CharField()
    clase = forms.CharField()
    efecto = forms.CharField()
    item = forms.IntegerField()

