from django.db import models

# Create your models here.
class Persona(models.Model):

    nombre = models.CharField(max_length = 99)
    dni = models.IntegerField()
    fn = models.DateField()

class Mapa(models.Model):

    mapa = models.CharField(max_length=99)
    dni = models.IntegerField()
    tier = models.IntegerField()

class Inusual(models.Model):

    cosmetico = models.CharField(max_length=99)
    clase = models.CharField(max_length=9)
    efecto = models.CharField(max_length=99)
    item = models.IntegerField()

